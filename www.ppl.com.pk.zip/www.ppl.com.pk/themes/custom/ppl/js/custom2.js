jQuery(function() {
    'use strict';

    var jQueryswipeTabsContainer = jQuery('.swipe-tabs'),
        jQueryswipeTabs = jQuery('.swipe-tab'),
        jQueryswipeTabsContentContainer = jQuery('.swipe-tabs-container'),
        currentIndex = 0,
        activeTabClassName = 'active-tab';

    jQueryswipeTabsContainer.on('init', function(event, slick) {
        jQueryswipeTabsContentContainer.removeClass('invisible');
        jQueryswipeTabsContainer.removeClass('invisible');

        currentIndex = slick.getCurrent();
        jQueryswipeTabs.removeClass(activeTabClassName);
        jQuery('.swipe-tab[data-slick-index=' + currentIndex + ']').addClass(activeTabClassName);
    });

    jQueryswipeTabsContainer.slick({
        //slidesToShow: 3.25,
        slidesToShow: 8,
        slidesToScroll: 1,
        arrows: true,
        infinite: true,
        swipeToSlide: true,
        touchThreshold: 10
    });

    jQueryswipeTabsContentContainer.slick({
        asNavFor: jQueryswipeTabsContainer,
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        infinite: true,
        swipeToSlide: true,
        draggable: false,
        touchThreshold: 10
    });


    jQueryswipeTabs.on('click', function(event) {
        // gets index of clicked tab
        currentIndex = jQuery(this).data('slick-index');
        jQueryswipeTabs.removeClass(activeTabClassName);
        jQuery('.swipe-tab[data-slick-index=' + currentIndex + ']').addClass(activeTabClassName);
        jQueryswipeTabsContainer.slick('slickGoTo', currentIndex);
        jQueryswipeTabsContentContainer.slick('slickGoTo', currentIndex);
    });

    //initializes slick navigation tabs swipe handler
    jQueryswipeTabsContentContainer.on('swipe', function(event, slick, direction) {
        currentIndex = jQuery(this).slick('slickCurrentSlide');
        jQueryswipeTabs.removeClass(activeTabClassName);
        jQuery('.swipe-tab[data-slick-index=' + currentIndex + ']').addClass(activeTabClassName);
    });

    // jQuery(".nav-fill a").click(function() {
    // 	jQuery(".nav-fill a").removeClass("show active");
    // 	jQuery(this).toggleClass("show active");
    // });

    jQuery('.nav-tabs div a').on('click', function(e) {
        e.preventDefault()
        jQuery('.nav-tabs div a').removeClass("show active");
    })

    jQuery(".links-icons").click(function() {
        jQuery("#navbar-top").css("transform", "translateY(0%)");
    });

    jQuery(".ql-mobile-header a").click(function() {
        jQuery("#navbar-top").css("transform", "translateY(-100%)");
    });

    jQuery("#CollapsingNavbar").addClass('show');

    jQuery(".top-nav-icon").click(function() {
        jQuery(".top-navigation").css("transform", "translateX(0)");
    });

    jQuery("#mobile-header ul li a.search-icon").click(function() {
        jQuery("#navbar-main .navbar-brand").hide();
        jQuery("#navbar-main > .container").show();
    });

    jQuery(".mn-mobile-header a").click(function() {
        jQuery("body").css("overflow", "scroll");
        jQuery(".top-nav-icon").css("display", "block");
        jQuery(".top-navigation").css("transform", "translateX(-100%)");
    });

    jQuery("input#edit-keyword[type='text'], input#edit-keyword--2[type='text']").attr("placeholder", "Search");

    jQuery(".top-navigation ul.menu.menu-level-0 li a").hover(
        function() {
            jQuery(this).addClass("active-menu");
        },
        function() {
            jQuery(this).removeClass("active-menu");
        }
    );

    jQuery(".top-navigation ul.menu.menu-level-0 li a").hover(
        function() { // Mouse Over
            jQuery(".menu_link_content").parent().addClass("active-menu");
        },
        function() { // Mouse Out
            jQuery(".menu_link_content").parent().removeClass("active-menu");
        }
    );

    jQuery(".overlay .closeBtn a").click(function() {
        jQuery(".overlay").css("transform", "translate(-100%)");
    });

    jQuery(".block-views-blocksection-3-block-1 .section_3_in_order_left img").click(function() {
        jQuery(".overlay").css("transform", "translate(0)");
        var image_src = jQuery(this).attr('src');
        jQuery(".overlay div img").attr('src', image_src);
    });

    jQuery(".collapse").on('show.bs.collapse', function() {
        jQuery(this).prev("a").find(".fa").removeClass("fa-plus-circle").addClass("fa-minus-circle");
    }).on('hide.bs.collapse', function() {
        jQuery(this).prev("a").find(".fa").removeClass("fa-minus-circle").addClass("fa-plus-circle");
    });

    jQuery(".awards-slider").slick({
        dots: false,
        infinite: true,
        centerMode: true,
        centerPadding: '276px',
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: true,
        nextArrow: jQuery('#next'),
        prevArrow: jQuery('#prev'),
        responsive: [{
            breakpoint: 767,
            settings: {
                centerMode: false,
                centerPadding: '0px',
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });

    jQuery(".page-node-131 .inner-page-structure .inner-content-section .container .row .col-lg-12 .col-left > div, .page-node-185 .inner-page-structure .inner-content-section .container .row .col-lg-12 .col-left > div").addClass("table-responsive");

    jQuery('area').cluetip({
        splitTitle: '|', // use the invoking element's title attribute to populate the clueTip...
        // ...and split the contents into separate divs where there is a "|"
        showTitle: true, // hide the clueTip's heading
        activation: 'hover',
        width: 250,
        dropShadow: false,
        cursor: 'none'
    });

    jQuery('map').imageMapResize();

    jQuery(document).on('mousemove', function(e) {
        var pageX = e.pageX;
        var pageY = e.pageY;
        jQuery(".moveAble")
            .css({
                left: e.pageX - 5,
                top: e.pageY - 230,
            })
    });

    const cursor = document.querySelector('.cursor');

    if (jQuery('.maps-section').length) {

        var activitymaps = document.getElementsByClassName("maps-section");

        activitymaps[0].addEventListener('mousemove', function(e) {
            cursor.setAttribute("style", "top: " + (e.pageY - 240) + "px; left: " + (e.pageX - 14) + "px;")
        })

        // activitymaps[0].addEventListener('mousemove', e => {
        // 	cursor.setAttribute("style", "top: "+(e.pageY - 240)+"px; left: "+(e.pageX - 14)+"px;")
        // })

        activitymaps[0].addEventListener('click', function() {
            cursor.classList.add("expand");

            setTimeout(function() {
                cursor.classList.remove("expand");
            }, 500)
        });

    };

    jQuery('#PPL-Production-Assests-Table').tablesorter({
        widgets: ['jfilterselect']
    });
    jQuery('.unsortable').unbind();

    // jQuery("#pro-tab-show").click(function() {
    // 	jQuery('html, body').animate({
    // 		scrollTop: jQuery("#production-table-details").offset().top
    // 	}, 2000);
    // });

    jQuery(".sticky-quick-links a.ql-btn").click(function() {
        jQuery(".slide-box").css("right", "0");
    });

    jQuery(".ql-cross").click(function() {
        jQuery(".slide-box").css("right", "-254px");
    });

    if (jQuery('.menu--election-quicklinks').length) {
        jQuery('.menu--election-quicklinks').prepend('<a href="javascript:void(0);" class="ql-btn">&nbsp;</a>');
        jQuery('.menu--election-quicklinks h2').append('<a href="javascript:void(0);" class="ql-cross">&nbsp;</a>');
    }

    jQuery(".menu--election-quicklinks a.ql-btn").click(function() {
        jQuery(".menu--election-quicklinks h2, .menu--election-quicklinks ul").css("transform", "translate(0%, 0px)");
    });

    jQuery(".ql-cross").click(function() {
        jQuery(".menu--election-quicklinks h2, .menu--election-quicklinks ul").css("transform", "translate(100%, 0px)");
    });

    // var mobileWidth2 = window.innerWidth;

    // if (mobileWidth2 <= 767) {

    // 	jQuery('#block-bootstrap-barrio-ppl-footer').append('#block-copyrights');

    // }

    jQuery(".slickCaptionThumb").slick({
        dots: true,
        infinite: true,
        speed: 500,
        fade: false,
        slide: 'li',
        cssEase: 'linear',
        //centerMode: true,
        slidesToShow: 1,
        //variableWidth: true,
        autoplay: true,
        autoplaySpeed: 4000,
        // responsive: [{
        // 	breakpoint: 800,
        // 	settings: {
        // 		arrows: false,
        // 		centerMode: false,
        // 		centerPadding: '40px',
        // 		variableWidth: false,
        // 		slidesToShow: 1,
        // 		dots: true
        // 	},
        // }],
        customPaging: function(slider, i) {
            return '<button class="tab">' + jQuery('.slick-thumbs li:nth-child(' + (i + 1) + ')').html() + '</button>';
        }
    });

    // live handler
    if (jQuery('.elem').length) {
        lc_lightbox('.elem', {
            wrap_class: 'lcl_fade_oc',
            gallery: true,
            thumb_attr: 'data-lcl-thumb',
            fullscreen: true,
            skin: 'light',
            radius: 0,
            padding: 0,
            border_w: 0,
            txt_toggle_cmd: false
        });
    }

    jQuery('.progress-language a, .hfw-italic h2 a span').each(function() {
        var word = jQuery(this).html();
        var index = word.indexOf(' ');
        if (index == -1) {
            index = word.length;
        }
        jQuery(this).html('<span class="w-progress">' + word.substring(0, index) + '</span>' + word.substring(index, word.length));
    });

    var mobileWidth = window.innerWidth;

    if (mobileWidth <= 768) {
        // jQuery(".site-footer ul.navbar-nav li.menu-item--expanded > a").attr("href", "javascript:Void(0)");
        // jQuery('.menu--footer ul.menu').hide();
        // jQuery('.menu--footer > ul > li > a').click(function() {
        // 	jQuery('.menu--footer ul.menu').hide();
        // 	jQuery(this).next('.menu--footer ul.menu').slideToggle().siblings('.menu--footer ul.menu:visible').slideUp();
        // });
        jQuery("#block-bootstrap-barrio-ppl-views-block-section2-block-1 .views-field-title a").attr("href", "javascript:Void(0)");
        jQuery("#block-bootstrap-barrio-ppl-views-block-section2-block-1 .view-id-section2 .views-row").click(function() {
            jQuery(this).css({
                "height": "173px"
            });
        });

        jQuery(".top-navigation ul.menu.menu-level-0 > li > a").attr("href", "javascript:void(0);");

        jQuery(".top-navigation ul.menu.menu-level-0 > li > a").click(function(e) {
            e.preventDefault()
            jQuery("ul.menu.menu-level-0 > li > a:not(.active-menu)").parent('.menu-item').find(".menu_link_content").removeClass("top-mdn");
            jQuery(this).parent('.menu-item').find(".menu_link_content:first").toggleClass("top-mdn");
        });
    }

});