// Dropdown Menu Fade    
jQuery(document).ready(function() {

    jQuery(".dropdown").hover(
        function() {
            jQuery('.dropdown-menu', this).fadeIn("fast");
        },
        function() {
            jQuery('.dropdown-menu', this).fadeOut("fast");
        });

    jQuery(".top-nav-icon").click(function() {
        jQuery(this).hide();
    });

});